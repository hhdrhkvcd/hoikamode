name="Балканы 1980–2008: распад Югославии"
version="1.0"
tags={
    "Alternative History"
    "Events"
    "Gameplay"
    "Historical"
    "National Focuses"
}
