name="Umalilend Merged - Taiwan 100 / Japan 200 (Repaired)"
version="2.7"
tags={
    "Alternative History"
    "National Focuses"
    "Events"
    "Gameplay"
}
supported_version="1.19.*"
path="mod/Umalilend_Merged"
