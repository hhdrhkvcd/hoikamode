-- Experimental: Millennium Dawn is designed around its 2000 start.
NDefines.NGame.START_DATE = "1980.5.1.12"
